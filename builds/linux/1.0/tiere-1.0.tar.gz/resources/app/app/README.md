![Tiere Icon](./img/app-s.png)

# Tiere
Interaktive Webapp für Schulkinder zum Thema Tiere
